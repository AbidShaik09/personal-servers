﻿// See https://aka.ms/new-console-template for more information
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text.Json.Nodes;

Console.WriteLine("Hello, World!");
SqlConnection connection = new SqlConnection("server=.\\SQLEXPRESS; initial catalog=userTestDb; user id=sa;password=Pass@123 ; trustServerCertificate= true;");
var command = new SqlCommand();
command.Connection = connection;    
command.CommandText = "USE userTestDb";
try
{
    connection.Open();
    command.ExecuteNonQuery();
    /*
         command.CommandText = "insert into usertable values(12,'pass')";

        command.ExecuteNonQuery();
        connection.Close();
        Console.WriteLine("Executed Successfully");
     */
    command.CommandText = "insert into usertable values(1,'password')";

    command.ExecuteNonQuery();
    command.CommandText = "select * from usertable";
    SqlDataReader reader =  command.ExecuteReader();
    while (reader.Read())
    {
        Console.WriteLine(reader[0].ToString()+" " + reader[1].ToString());
        reader.NextResult();
    }

}
catch (Exception e)
{
    Console.WriteLine("Error");
}