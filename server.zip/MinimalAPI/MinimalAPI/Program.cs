var builder = WebApplication.CreateBuilder(args);
builder.Services.AddCors();
// Add services to the container.

var app = builder.Build();

app.UseCors((option) =>
{
    option.AllowAnyHeader();
    option.AllowAnyMethod();
    option.AllowAnyOrigin();
});
// Configure the HTTP request pipeline.


app.MapGet("/weatherforecast", () =>
{
   
    return "Hi";
});

app.Run();

internal record WeatherForecast(DateOnly Date, int TemperatureC, string? Summary)
{
    public int TemperatureF => 32 + (int)(TemperatureC / 0.5556);
}
