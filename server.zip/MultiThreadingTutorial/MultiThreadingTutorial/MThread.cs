﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiThreadingTutorial
{
    internal class MThread
    {
        public static async Task exec()
        {
            Parallel.For(0, 10, (i) => { Console.WriteLine(i); });
            Task.Run(() => { Function1(); });
            await Task.Run(() => { Function2(); });

            Parallel.Invoke(Function1, Function2,Function3);
        }
        static void Function1()
        {
            Console.WriteLine("Function1 Executed");
        }
        static async void Function2()
        {
            for (int i = 0; i < 10; i++)
            {

                Console.WriteLine("Function2 Executed");
                Thread.Sleep(1000);

            }
        }
        static async void Function3()
        {
            for (int i = 0; i < 10; i++)
            {

                Console.WriteLine("Function3 Executed");
                Thread.Sleep(1000);

            }
        }
    }
}
