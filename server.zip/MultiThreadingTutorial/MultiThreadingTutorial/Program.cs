﻿// See https://aka.ms/new-console-template for more information
using MultiThreadingTutorial;

Console.WriteLine("Hello, World!");
await MThread.exec();