const http = require('http')
const products = require('./controllers/products')
const getController = require('./controllers/get-controller')
const postController =require('./controllers/post-controller')
const server = http.createServer((req, res) => {
    switch(req.method){
        case "GET":
            getController(req,res);
            break;
        
        case "POST":
            postController(req,res);
            break;
        default:
            res.writeHead(400);
            res.end(JSON.stringify({
              data: 'method not supported',
            }));
            break;

            
    }
});
server.listen(3000,()=>{
    console.log("Server started")
});


