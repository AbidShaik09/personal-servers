﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class FileName
    {
        public static void exec()
        {
            Func<int, int, string>f = getAddress;
            Console.WriteLine(f(12,13));
            f = (x, y) => "address";
            Console.WriteLine(f(12,13));
            Action<int, int> a= (x, y) => { Console.WriteLine(x + y); };
            a(4,5);
            Predicate<int> p = (x) => true;

        }
        public static string getAddress(int a, int b)
        {
            return "address here";
        }
    }
}
