module.exports={
    data : null,
    getJson:()=>{
        const product = require('./products.json')
        //console.log(JSON.stringify(product)); 
        return product;
    },

    postJson:(data)=>{
        const product = require('./products.json')
        console.log(data)
        //product.push(data)
    }
}
