module.exports=(req,res)=>{
    if(req.url==='/api/products'){
        const productmethod = require('./products')
        let result = productmethod.getJson()
       
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(
            JSON.stringify({
                data: result
            })
        );
    }
    else{
        res.writeHead(404, { 'Content-Type': 'application/json' });
        
        console.log(req.url);
        res.end();
    }
    

}