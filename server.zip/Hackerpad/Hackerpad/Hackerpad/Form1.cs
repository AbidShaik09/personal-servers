namespace Hackerpad
{
    public partial class Form1 : Form
    {
        private string fileName = "";
        public Form1()
        {
            InitializeComponent();
        }

        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.ShowDialog(this);
            fileName = ofd.FileName;
            textBox1.Text = File.ReadAllText(ofd.FileName);
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (File.Exists(fileName))
            {
                File.WriteAllText(fileName, textBox1.Text);

            }
            else
            {
                SaveFileDialog ofd = new SaveFileDialog();
                ofd.ShowDialog(this);
               
                fileName = ofd.FileName;
                File.WriteAllText(ofd.FileName, textBox1.Text);
            }

        }

        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {

            SaveFileDialog ofd = new SaveFileDialog();
            ofd.ShowDialog(this);
    

            fileName = ofd.FileName;
            File.WriteAllText(ofd.FileName, textBox1.Text);
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (File.Exists(fileName))
            {
                File.WriteAllText(fileName, textBox1.Text);

            }
            else
            {
                SaveFileDialog ofd = new SaveFileDialog();
                ofd.ShowDialog(this);
                
                fileName = ofd.FileName;
                File.WriteAllText(ofd.FileName+ ".txt", textBox1.Text);
            }
            this.Close();
        }

        private void changeFontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FontDialog fontDialog = new FontDialog();
            fontDialog.ShowDialog(this);
            if(fontDialog.Font!=null)
            textBox1.Font = fontDialog.Font;
        }

        private void changeBackgroundToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ColorDialog colorDialog = new ColorDialog();
            colorDialog.ShowDialog(this);
            if(colorDialog.Color!=null)
           
            textBox1.BackColor = colorDialog.Color;
        }
    }
}
