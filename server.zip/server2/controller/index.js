const products = [
    {
        "id":1,
        "name":"lays",
        "price":20
    },
    {
        "id":2,
        "name":"Uncle Chips",
        "price":20
    },   
]

const GetProducts = (req,res)=>{
    res.status(200)
    res.send( products)
}
const GetProduct = (req,res)=>{
    var id=  req.params.id
    var product =  products.find(p=>(req.params.id ==p.id));
    if(product == null){
        res.status = 404
        res.send({"error":"item with id: "+id +" not found"})
    }
    res.status = 200
    res.send({status: 200 , item: product})
}
const AddProduct =(req,res)=>{
    let body = ( req.body)
    console.log(body)
    if(body.id ==null || products.find((p)=>p.id ==body.id)){
        res.status = 400
        res.send({"error": "not a valid id"})
    }
    let p = {
        "id":body.id,
        "name":body.name,
        "price":body.price
    }
    products.push(p)
    res.status = 200
    res.send({"success": "item added successfully"})

}
const UpdateProduct = (req,res)=>{
    let prod = products.find(p=>p.id == req.body.id)
    if(prod == null){
        res.status=404
        res.send({error: 'product not found'})

    }
    prod.name =req.body.name
    prod.price=req.body.price 
    res.status=200

    res.send({"message":"item updated successfully "})
}
const DeleteProduct =(req,res)=>{
    let prod = products.find(p=>req.params.id==p.id)
    if (prod==null){
        res.status =404
        res.send({error: "product not found"})
    } 
    products.pop(prod)
    res.status = 200
    res.send({message : "item deleted successfully"})
}

module.exports =  {GetProducts, GetProduct, AddProduct,UpdateProduct, DeleteProduct}  