const express = require("express");
const {GetProducts, GetProduct, AddProduct, UpdateProduct,DeleteProduct } = require('../controller')

const router = express.Router()
router.get("/products",GetProducts)

router.get("/product/:id",GetProduct)
router.put("/product",UpdateProduct)
router.delete("/product/:id",DeleteProduct)
router.post("/product/",AddProduct)


module.exports = {router}