module.exports = async (req,res)=>{
    if(req.url ==="/api/products"){
        let body = '';
        const product = require("./products")
        await req.on('data',chunk =>{
            body+=chunk
        });
        product.postJson(body);
        res.writeHead(201,{ 'Content-Type': 'application/json' });
    
        res.end("Data.recieved");
    }
    else{
        res.status = 404;
        res.end();
    }

}