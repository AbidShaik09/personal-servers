const express = require('express');
app = express();
port = 3000;
let products = [
    {
        "id":1,
        "name":"lays",
        "price":20
    },
    {
        "id":2,
        "name":"Uncle Chips",
        "price":20
    },
    
    
]
app.use(express.json())
app.get("/api/products",(req,res)=>{
    
        res.send(JSON.stringify(products)) 
    }
)
app.get("/api/products/:id",(req,res)=>{
    
    res.send(JSON.stringify(products.filter( (p)=>{
       if(p.id  == req.params.id) {
        return p
       }
       else{
        return null
       }
    } ))) 
}
)
app.post("/api/products", (req,res)=>{
        
        console.log(req.body)
        products.push(req.body)
        res.send(products)
    }
)

app.delete("")

app.listen(port,()=>{
    console.log("started on : "+port)
})